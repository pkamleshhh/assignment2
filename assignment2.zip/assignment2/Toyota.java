package assignment2;

public class Toyota extends Car{

}
