package assignment2;

public class Maruti extends Car {

}
