package assignment2;

import java.util.ArrayList;
import java.util.Scanner;

public class Customer {
    int customerId;
    String customerName;
    ArrayList<Car> carList;
    Scanner sc=new Scanner(System.in);
    Customer(){
        System.out.println("Enter Customer Id");
        customerId=Integer.parseInt(sc.nextLine());
        System.out.println("Enter Customer Name");
        customerName=sc.nextLine();
        carList=new ArrayList<>();
    }
    Customer(int customerId, String customerName, ArrayList<Car>carList) {
        this.customerId=customerId;
        this.customerName=customerName;
        this.carList=carList;
    }
    public int getCustomerId(){
        return customerId;
    }
    public String getCustomerName(){
        return customerName;
    }
    public ArrayList<Car> getCarList(){
        return carList;
    }
    public void setCarList(final ArrayList<Car> carList){
        this.carList=carList;
    }
}
