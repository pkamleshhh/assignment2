package assignment2;
import java.util.*;
import java.util.jar.JarOutputStream;


class Main{
    public static void main(String[] args) {
        List<Customer> customerList=new ArrayList<Customer>();
        List<Car>carList=new ArrayList<Car>();
        int randId[]=new int[20];
        Scanner sc=new Scanner(System.in);
        int input;
        System.out.println("    Hello");
        System.out.println(" Enter Username");
        String username=sc.nextLine();
        System.out.println(" Enter Password");
        String password=sc.nextLine();
        if(username.equals("admin") && password.equals("admin")){
            System.out.println(">---Welcome---<");
            do {
                System.out.println("Press 1 to Add Customer:, 2 to Delete Customer:, 3 to Display Records:,4 to Edit Car List:,5 to slect Random Number:,6 to Exit");
                input= Integer.parseInt(sc.nextLine());
                switch(input){
                    case 1:
                        customerList.add(new Customer());
                        System.out.println("New Customer Added");
                        break;
                    case 2:
                        Scanner read=new Scanner(System.in);
                        System.out.println("Enter Customer Id To Be Deleted");
                        int delKey;
                        if(read.hasNext()){
                            delKey=read.nextInt();
                            int lengthList=customerList.size();
                            for (int i = 0; i <lengthList ; i++) {
                                if(customerList.get(i).getCustomerId()==delKey){
                                    customerList.remove(i);
                                    System.out.println("Customer Removed");
                                } else {
                                    System.out.println("Key Not Found");
                                }
                            }
                        }
                        else{
                            System.out.println("Enter a valid key");
                        }
                        break;
                    case 3:
                        for (int i = 0; i < customerList.size() ; i++) {
                            System.out.println("Customer Id:"+customerList.get(i).getCustomerId()+"  Customer Name:"+customerList.get(i).getCustomerName());
                            for(Car c:customerList.get(i).getCarList()){
                                System.out.println("Car Id:"+c.getCarId()+"   Car Type:"+c.getCarType()+"  Car Model:"+c.getCarModel()+"  Car Price:"+c.getCarPrice()+"  Resale Price:"+c.getResalePrice());
                            }
                        }
                        break;
                    case 4:
                        Scanner scan=new Scanner(System.in);
                        System.out.println("Enter Customer Id");
                        int num=0;
                        if(scan.hasNext()){
                            num=scan.nextInt();
                            int lengthList=customerList.size();
                            for (int i = 0; i <lengthList ; i++) {
                                if(customerList.get(i).getCustomerId()==num){
                                    Customer c=customerList.get(i);
                                    ArrayList<Car> car=c.getCarList();
                                    car.add(new Car() {

                                    });
                                    c.setCarList(car);
                                    System.out.println("Car Has Been Added");
                                }
                                else{
                                    System.out.println("Customer Does Not Exist");
                                }
                            }
                        }
                        else{
                            System.out.println("Enter a valid key");
                        }
                        break;
                    case 5:
                        int lengthList=customerList.size();
                        for (int i = 0; i <lengthList ; i++) {
                           randId[i]=customerList.get(i).getCustomerId();
                        }
                            Random r=new Random();
                            int randomInteger= r.nextInt(customerList.size());
                            System.out.println("The id that has been selected is:" + customerList.get(randomInteger).getCustomerId());
                         break;
                    case 6:
                        System.out.println("Goodbye");
                        break;
                }
            }
            while (input!=6);
        }
        else{
            System.out.println("Not An Admin");
        }

    }
}