package assignment2;

import java.util.Scanner;

abstract class  Car{
    int carId;
    String carType;
    String carModel;
    int carPrice;
    double resalePrice;
    Scanner sc=new Scanner(System.in);
    Car(){
        System.out.println("Enter Car Id:");
        carId= Integer.parseInt(sc.nextLine());
        System.out.println("Enter Car Type");
        carType=sc.nextLine();
//      do {
//
//      }
//      while(!carType.equals(""));
        System.out.println("Enter Car Model");
        carModel=sc.nextLine();
        System.out.println("Enter Car Price");
        carPrice=Integer.parseInt(sc.nextLine());
    }
    public int getCarId(){
        return carId;
    }
    public String getCarType(){
        return carType;
    }
    public String getCarModel(){
        return carModel;
    }
    public int getCarPrice(){
        return carPrice;
    }
        public double getResalePrice(){
            if(getCarType().equals("hyundai")){
                return carPrice*0.4;
            }
            else if("toyota".equals(getCarType())){
                return carPrice*0.8;
            }
            else{
                return carPrice*0.6;
            }
        }
    public Car(int carId,String carType,String carModel,int carPrice,double resalePrice){
        this.carId=carId;
        this.carType=carType;
        this.carModel=carModel;
        this.carPrice=carPrice;
        this.resalePrice=resalePrice;
    }
}