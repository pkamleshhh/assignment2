package assignment2;

public class Hyundai extends Car {

}
